const AdvancedLuauTokenFilterPipeline = {
    processAndCleanTokenStream: function(rawSourceString) {
        let currentCursor = 0;
        let targetStreamAccumulator = "";
        const streamLength = rawSourceString.length;
        while (currentCursor < streamLength) {
            let character = rawSourceString[currentCursor];
            let lookaheadCharacter = rawSourceString[currentCursor + 1];
            if (character === '"' || character === "'") {
                let dynamicQuoteBoundary = character;
                targetStreamAccumulator += character;
                currentCursor++;
                while (currentCursor < streamLength && rawSourceString[currentCursor] !== dynamicQuoteBoundary) {
                    if (rawSourceString[currentCursor] === '\\') {
                        targetStreamAccumulator += '\\' + rawSourceString[currentCursor + 1];
                        currentCursor += 2;
                    } else {
                        targetStreamAccumulator += rawSourceString[currentCursor];
                        currentCursor++;
                    }
                }
                if (currentCursor < streamLength) {
                    targetStreamAccumulator += rawSourceString[currentCursor];
                    currentCursor++;
                }
                continue;
            }
            if (character === '`') {
                targetStreamAccumulator += '"';
                currentCursor++;
                let deepBraceStackCounter = 0;
                while (currentCursor < streamLength && (rawSourceString[currentCursor] !== '`' || deepBraceStackCounter > 0)) {
                    if (rawSourceString[currentCursor] === '{') {
                        targetStreamAccumulator += '" .. tostring(';
                        currentCursor++;
                        deepBraceStackCounter++;
                    } else if (rawSourceString[currentCursor] === '}') {
                        targetStreamAccumulator += ') .. "';
                        currentCursor++;
                        deepBraceStackCounter--;
                    } else {
                        targetStreamAccumulator += rawSourceString[currentCursor];
                        currentCursor++;
                    }
                }
                if (currentCursor < streamLength) {
                    targetStreamAccumulator += '"';
                    currentCursor++;
                }
                continue;
            }
            if (character === '-' && lookaheadCharacter === '-') {
                currentCursor += 2;
                if (rawSourceString[currentCursor] === '[' && rawSourceString[currentCursor + 1] === '[') {
                    currentCursor += 2;
                    while (currentCursor < streamLength && !(rawSourceString[currentCursor] === ']' && rawSourceString[currentCursor + 1] === ']')) {
                        currentCursor++;
                    }
                    currentCursor += 2;
                } else {
                    while (currentCursor < streamLength && rawSourceString[currentCursor] !== '\n') {
                        currentCursor++;
                    }
                }
                continue;
            }
            if (character === ':' && lookaheadCharacter === ':') {
                currentCursor += 2;
                while (currentCursor < streamLength && !(/[\n,;)]/.test(rawSourceString[currentCursor]))) {
                    currentCursor++;
                }
                continue;
            }
            if (character === ':') {
                let diagnosticForwardPointer = currentCursor + 1;
                while (diagnosticForwardPointer < streamLength && /\s/.test(rawSourceString[diagnosticForwardPointer])) {
                    diagnosticForwardPointer++;
                }
                if (/[A-Za-z_]/.test(rawSourceString[diagnosticForwardPointer])) {
                    let analyticalWord = "";
                    while (diagnosticForwardPointer < streamLength && /[A-Za-z0-9_]/.test(rawSourceString[diagnosticForwardPointer])) {
                        analyticalWord += rawSourceString[diagnosticForwardPointer];
                        diagnosticForwardPointer++;
                    }
                    if (["string", "number", "boolean", "any", "unknown", "thread", "table", "function", "nil"].includes(analyticalWord)) {
                        currentCursor = diagnosticForwardPointer;
                        continue;
                    }
                }
            }
            targetStreamAccumulator += character;
            currentCursor++;
        }
        let finalNormalizedSourceStream = targetStreamAccumulator;
        finalNormalizedSourceStream = finalNormalizedSourceStream.replace(/\b(export\s+)?type\s+[a-zA-Z0-9_]+\s*=.+?(?=\n|;|$)/g, "");
        finalNormalizedSourceStream = finalNormalizedSourceStream.replace(/\bif\s+(.+?)\s+then\s+(.+?)\s+else\s+(.+?)(?=\n|;|,|\)|$)/g, "(($1) and ($2) or ($3))");
        const standardCompoundsList = [
            { operatorToken: '\\+=', operationalSymbol: '+' },
            { operatorToken: '-=', operationalSymbol: '-' },
            { operatorToken: '\\*=', operationalSymbol: '*' },
            { operatorToken: '/=', operationalSymbol: '/' },
            { operatorToken: '%=', operationalSymbol: '%' },
            { operatorToken: '\\^=', operationalSymbol: '^' },
            { operatorToken: '\\.\\.=', operationalSymbol: '..' }
        ];
        standardCompoundsList.forEach(nodeItem => {
            const trackingRegexPattern = new RegExp(`^(\\s*)([A-Za-z0-9_.\\[\\]"']+)\\s*${nodeItem.operatorToken}\\s*(.+)$`, 'gm');
            finalNormalizedSourceStream = finalNormalizedSourceStream.replace(trackingRegexPattern, `$1$2 = $2 ${nodeItem.operationalSymbol} ($3)`);
        });
        finalNormalizedSourceStream = finalNormalizedSourceStream.replace(/\bcontinue\b/g, "__VOZEX_APEX_CONTINUE_POINTER_INVARIANT__()");
        return finalNormalizedSourceStream;
    }
};