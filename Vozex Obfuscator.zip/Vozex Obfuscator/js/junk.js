function generatePolymorphicJunkBlock(targetSizeKb) {
    let buffer = "local _VZX_JUNK_MATRIX = [[\n";
    const targetBytes = targetSizeKb * 1024;
    let currentSize = 0;
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_!@#$%^&*()=+-';
    while(currentSize < targetBytes) {
        let chunk = '';
        for(let i=0; i<120; i++) {
            chunk += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        chunk += '\n';
        buffer += chunk;
        currentSize += chunk.length;
    }
    buffer += "]]\n";
    buffer += "if #_VZX_JUNK_MATRIX > 999999 then print(_VZX_JUNK_MATRIX) end\n";
    return buffer;
}
