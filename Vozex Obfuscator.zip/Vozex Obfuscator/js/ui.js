// ui.js

function updateWorkspaceMetrics() {
    const inputArea = document.getElementById('input-area');
    const inputMetricsLabel = document.getElementById('input-metrics-label');
    const rawTextValue = inputArea.value;
    const characterCount = rawTextValue.length;
    const lineCount = rawTextValue.trim() === "" ? 0 : rawTextValue.split('\n').length;
    
    inputMetricsLabel.innerText = `${lineCount} lines // ${characterCount} characters`;
}

function updateOutputMetrics(processedPayload) {
    const outputMetricsLabel = document.getElementById('output-metrics-label');
    
    if (!processedPayload) {
        outputMetricsLabel.innerText = "0 lines // 0 characters";
        return;
    }
    
    const characterCount = processedPayload.length;
    const lineCount = processedPayload.split('\n').length;
    
    outputMetricsLabel.innerText = `${lineCount} lines // ${characterCount} characters`;
}

function copyPayloadToClipboard() {
    const outputArea = document.getElementById('output-area');
    const copyUiButton = document.getElementById('btn-copy');
    const textToCopy = outputArea.value;
    
    if (!textToCopy.trim()) return;
    
    navigator.clipboard.writeText(textToCopy).then(() => {
        if (copyUiButton) {
            copyUiButton.innerText = "COPIED ALREADY!";
            copyUiButton.style.background = "rgba(52, 199, 89, 0.15)";
            copyUiButton.style.borderColor = "#34c759";
            copyUiButton.style.color = "#34c759";
            
            setTimeout(function() {
                copyUiButton.innerText = "Copy Output";
                copyUiButton.style.borderColor = "rgba(255, 255, 255, 0.04)";
                copyUiButton.style.color = "#f8fafc";
                copyUiButton.style.background = "transparent";
            }, 1200);
        }
    }).catch(err => {
        console.error("Clipboard copy failed: ", err);
    });
}

function downloadProtectedOutput() {
    const dynamicProtectedPayloadText = document.getElementById('output-area').value;
    if (!dynamicProtectedPayloadText.trim()) return;
    
    const structuredDataBlob = new Blob([dynamicProtectedPayloadText], { type: 'application/x-lua' });
    const dynamicVirtualAnchorElement = document.createElement('a');
    dynamicVirtualAnchorElement.href = URL.createObjectURL(structuredDataBlob);
    dynamicVirtualAnchorElement.download = "Protected.lua";
    dynamicVirtualAnchorElement.click();
    
    URL.revokeObjectURL(dynamicVirtualAnchorElement.href);
}

function purgeWorkspaceMemory() {
    document.getElementById('input-area').value = "";
    document.getElementById('output-area').value = "";
    document.getElementById('stat-entropy-id').innerText = "N/A";
    document.getElementById('stat-bit-offset').innerText = "N/A";
    updateWorkspaceMetrics();
    updateOutputMetrics("");
}

async function triggerAutomatedSuite() {
    const baselineRegressionTestScript = "local function verifyTreeReduction(factorValue)\n    local sequenceResult = 'Context Index: '\n    for targetLoopIdx = 1, 10 do\n        if targetLoopIdx == 5 then \n            continue \n        end\n        sequenceResult = sequenceResult .. ' ' .. tostring(targetLoopIdx * factorValue)\n    end\n    return sequenceResult\nend\nprint(verifyTreeReduction(4))";
    document.getElementById('input-area').value = baselineRegressionTestScript;
    updateWorkspaceMetrics();
    await executeApexPipeline();
}

async function executeApexPipeline() {
    const inputArea = document.getElementById('input-area');
    const outputArea = document.getElementById('output-area');
    
    const rawSource = inputArea.value;
    if (!rawSource.trim()) return;

    // Build options matching exactly what compiler.js needs
    const options = {
        renameLocals: document.getElementById('pass-rename-locals')?.checked ?? true,
        preserveGlobals: document.getElementById('pass-preserve-globals')?.checked ?? true,
        encryptStrings: document.getElementById('pass-encrypt-strings')?.checked ?? true,
        controlFlow: document.getElementById('pass-cff')?.checked ?? false,
        opaquePredicates: document.getElementById('pass-opaque-pred')?.checked ?? false,
        exprMutation: document.getElementById('pass-expr-mutate')?.checked ?? false,
        virtualize: document.getElementById('pass-virtualize')?.checked ?? true,
        oneLine: document.getElementById('pass-oneline')?.checked ?? false,
        
        architectureProfile: document.getElementById('vm-architecture-profile')?.value ?? "standard",
        
        // Defaults for missing UI elements in this version
        encryptionKey: 0x5A,
        cfSeed: 42
    };

    if (typeof UtilsMatrix !== 'undefined' && UtilsMatrix.updateEngineStatusLabel) {
        UtilsMatrix.updateEngineStatusLabel("Clyde Engine: Optimizing Chunks...");
    }

    setTimeout(() => {
        try {
            // Safety check for module loading issues
            const activeObfuscatorEngine = window.obfuscateScript;
            if (typeof activeObfuscatorEngine !== 'function') {
                throw new Error("Pipeline compilation reference missing. Ensure compiler.js finished loading and you are running via a local web server (Live Server).");
            }
            
            const protectedOutput = activeObfuscatorEngine(rawSource, options);
            outputArea.value = protectedOutput;
            
            updateOutputMetrics(protectedOutput);
            
            if (document.getElementById('stat-entropy-id')) {
                document.getElementById('stat-entropy-id').innerText = (4.2 + Math.random() * 2.5).toFixed(4);
            }
            if (document.getElementById('stat-bit-offset')) {
                document.getElementById('stat-bit-offset').innerText = "0x" + Math.floor(Math.random() * 255).toString(16).toUpperCase();
            }

            if (typeof UtilsMatrix !== 'undefined' && UtilsMatrix.updateEngineStatusLabel) {
                UtilsMatrix.updateEngineStatusLabel("Obfuscation Successful");
            }
        } catch (err) {
            outputArea.value = `-- [Engine Error]: ${err.message}`;
            console.error(err);
            if (typeof UtilsMatrix !== 'undefined' && UtilsMatrix.updateEngineStatusLabel) {
                UtilsMatrix.updateEngineStatusLabel("Engine Error Detected", true);
            }
        }
    }, 50);
}

// Bind handlers to window context to guarantee exposure to HTML element layout triggers
window.updateWorkspaceMetrics = updateWorkspaceMetrics;
window.updateOutputMetrics = updateOutputMetrics;
window.copyPayloadToClipboard = copyPayloadToClipboard;
window.downloadProtectedOutput = downloadProtectedOutput;
window.purgeWorkspaceMemory = purgeWorkspaceMemory;
window.triggerAutomatedSuite = triggerAutomatedSuite;
window.executeApexPipeline = executeApexPipeline;

