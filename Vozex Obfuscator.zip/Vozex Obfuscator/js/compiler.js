/**
 * Vozex Obfuscator Core Pipeline
 * Note: 'options' object now accepts specific toggle booleans.
 */
import { lex } from "./lexer/Lexer.js";
import { parse } from "./parser/Parser.js";
import { obfuscate } from "./obfuscator/Obfuscator.js";
import { encodeStrings } from "./obfuscator/StringEncoder.js";
import { scrambleControlFlow } from "./obfuscator/ControlFlowScrambler.js";
import { printChunk, printChunkOneLine } from "./obfuscator/Printer.js";
import { regCompile } from "./vm/RegCompiler.js";
import { generateRegVM } from "./vm/reg-vm-gen.js";

export function realObfuscateScript(rawSource, features = {}) {
    try {
        console.log(`[Vozex Engine] Engaging Pipeline with features:`, features);
        let currentCode = rawSource;

        // 1. Lexical Analysis (Required for all)
        const lexResult = lex(currentCode);
        if (lexResult.errors?.length > 0) throw new Error("Lexer Exception: " + lexResult.errors[0].message);

        // 2. AST Construction
        let ast = parse(lexResult.tokens);

        // 3. Vozex Engine Feature Pipeline (Direct Toggles)
        
        // Identifier Renaming
        if (features.renameLocals) {
            ast = obfuscate(ast, { renameLocals: true, preserveGlobals: features.preserveGlobals });
        }

        // Constant/String Encryption
        if (features.encryptStrings) {
            ast = encodeStrings(ast, { enabled: true, key: features.encryptionKey ?? 0x5A });
        }

        // Control Flow Flattening
        if (features.controlFlow) {
            ast = scrambleControlFlow(ast, { enabled: true, seed: features.cfSeed ?? 42 });
        }

        // Expression Mutation & Opaque Predicates
        if (features.opaquePredicates || features.exprMutation) {
             ast = obfuscate(ast, { 
                opaquePredicates: features.opaquePredicates, 
                mutateExpressions: features.exprMutation 
             });
        }

        // 4. Code Generation
        currentCode = features.oneLine ? printChunkOneLine(ast) : printChunk(ast);

        // 5. Virtualization (VM Architecture)
        if (features.virtualize) {
            console.log("[Vozex Engine] Compiling VM Bytecode...");
            const vmLex = lex(currentCode);
            const vmAst = parse(vmLex.tokens);
            const chunk = regCompile(vmAst);
            
            currentCode = generateRegVM(chunk, {
                level: "max",
                executorGlobals: true,
                polymorphicSeed: Date.now(),
                disableFeatures: [] 
            });
        }

        // Watermark removed. Code returns directly.
        return currentCode;

    } catch (error) {
        console.error("[Vozex Engine Error]:", error);
        return `-- [Engine Error]: ${error.message}`;
    }
}

window.obfuscateScript = realObfuscateScript;
console.log("[Vozex Engine] Global pipeline interface attached.");