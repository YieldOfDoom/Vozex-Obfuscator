const UtilsMatrix = {
    generateRandomString: function(length) {
        const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return result;
    },
    generateRandomIdentifier: function(length) {
        const leadCharacters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_';
        const bodyCharacters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_';
        let result = leadCharacters.charAt(Math.floor(Math.random() * leadCharacters.length));
        for (let i = 1; i < length; i++) {
            result += bodyCharacters.charAt(Math.floor(Math.random() * bodyCharacters.length));
        }
        return result;
    },
    stringToHexStream: function(str) {
        let hexString = '';
        for (let i = 0; i < str.length; i++) {
            let hexComponent = str.charCodeAt(i).toString(16);
            if (hexComponent.length < 2) hexComponent = '0' + hexComponent;
            hexString += '\\x' + hexComponent;
        }
        return hexString;
    },
    computeShannonEntropy: function(str) {
        if (!str) return 0;
        let characterFrequencies = {};
        for (let i = 0; i < str.length; i++) {
            const char = str.charAt(i);
            characterFrequencies[char] = (characterFrequencies[char] || 0) + 1;
        }
        let totalEntropySum = 0;
        for (const characterKey in characterFrequencies) {
            const frequencyProbability = characterFrequencies[characterKey] / str.length;
            totalEntropySum -= frequencyProbability * Math.log2(frequencyProbability);
        }
        return totalEntropySum;
    },
    xorEncryptStringToByteArray: function(str, key) {
        let encryptedOutput = [];
        for (let i = 0; i < str.length; i++) {
            encryptedOutput.push(str.charCodeAt(i) ^ key);
        }
        return encryptedOutput;
    },
    updateEngineStatusLabel: function(message, isError = false) {
        const statusLabel = document.getElementById('engine-status-label');
        if (!statusLabel) return;
        statusLabel.innerText = message;
        if (isError) {
            statusLabel.style.background = "rgba(255, 69, 58, 0.12)";
            statusLabel.style.borderColor = "rgba(255, 69, 58, 0.4)";
            statusLabel.style.color = "#ff453a";
            statusLabel.style.boxShadow = "0 0 20px rgba(255, 69, 58, 0.3)";
        } else {
            statusLabel.style.background = "rgba(191, 90, 242, 0.08)";
            statusLabel.style.borderColor = "rgba(191, 90, 242, 0.25)";
            statusLabel.style.color = "#f3e8ff";
            statusLabel.style.boxShadow = "0 0 20px rgba(191, 90, 242, 0.4)";
        }
    }
};

function generateUniqueCryptographicLabel(characterCount = 10) {
    const leadChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_';
    const bodyChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_';
    let labelBuffer = leadChars.charAt(Math.floor(Math.random() * leadChars.length));
    for (let index = 1; index < characterCount; index++) {
        labelBuffer += bodyChars.charAt(Math.floor(Math.random() * bodyChars.length));
    }
    return labelBuffer;
}
