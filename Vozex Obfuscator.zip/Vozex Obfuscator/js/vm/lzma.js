import { deflateRaw, inflateRaw } from "https://esm.run/pako";

export function base85Encode(data) {
    // Treat uniformly as unsigned byte structures inside browser contexts
    const uint8Data = data instanceof Uint8Array ? data : new Uint8Array(data);
    let padded = uint8Data;
    if (uint8Data.length % 4 !== 0) {
        const padLen = 4 - (uint8Data.length % 4);
        padded = new Uint8Array(uint8Data.length + padLen);
        padded.set(uint8Data);
    }
    let result = "";
    for (let i = 0; i < padded.length; i += 4) {
        // Strict bitmasking ensures accurate bitwise calculation across web engines
        const val = ((padded[i] & 0xFF) << 24) |
                    ((padded[i + 1] & 0xFF) << 16) |
                    ((padded[i + 2] & 0xFF) << 8) |
                    (padded[i + 3] & 0xFF);
        const uval = val >>> 0;
        if (uval === 0) {
            result += "z";
            continue;
        }
        let v = uval;
        const c = new Array(5);
        for (let j = 4; j >= 0; j--) {
            c[j] = String.fromCharCode(33 + (v % 85));
            v = Math.floor(v / 85);
        }
        result += c.join("");
    }
    return result;
}

export function base85Decode(str) {
    const result = [];
    let i = 0;
    str = str.replace(/z/g, "!!!!!");
    while (i < str.length) {
        if (i + 5 <= str.length) {
            let val = 0;
            for (let j = 0; j < 5; j++) {
                val = val * 85 + (str.charCodeAt(i + j) - 33);
            }
            result.push((val >>> 24) & 0xFF);
            result.push((val >>> 16) & 0xFF);
            result.push((val >>> 8) & 0xFF);
            result.push(val & 0xFF);
            i += 5;
        }
        else {
            const remaining = str.length - i;
            let val = 0;
            for (let j = 0; j < remaining; j++) {
                val = val * 85 + (str.charCodeAt(i + j) - 33);
            }
            for (let j = remaining; j < 5; j++) {
                val = val * 85 + 84;
            }
            for (let j = 0; j < remaining - 1; j++) {
                result.push((val >>> (24 - j * 8)) & 0xFF);
            }
            i += remaining;
        }
    }
    return new Uint8Array(result);
}

function adler32(data) {
    let a = 1, b = 0;
    const MOD = 65521;
    let idx = 0;
    while (idx < data.length) {
        const end = Math.min(idx + 5552, data.length);
        for (; idx < end; idx++) {
            a += data[idx];
            b += a;
        }
        a %= MOD;
        b %= MOD;
    }
    return b * 65536 + a;
}

function generateSBox(rng) {
    const sbox = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [sbox[i], sbox[j]] = [sbox[j], sbox[i]];
    }
    return sbox;
}

function invertSBox(sbox) {
    const inv = new Array(256);
    for (let i = 0; i < 256; i++) {
        inv[sbox[i]] = i;
    }
    return inv;
}

export function encryptAndEncode(input, rng) {
    const encoder = new TextEncoder();
    const raw = encoder.encode(input);
    const origLen = raw.length;
    const checksum = adler32(raw);
    const sbox = generateSBox(rng);
    const invSbox = invertSBox(sbox);
    const keyLen = 20 + Math.floor(rng() * 13);
    const xorKey = [];
    for (let i = 0; i < keyLen; i++) {
        xorKey.push(Math.floor(rng() * 256));
    }
    const substituted = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) {
        substituted[i] = sbox[raw[i]];
    }
    const encrypted = new Uint8Array(substituted.length);
    if (substituted.length > 0) {
        encrypted[0] = substituted[0] ^ xorKey[0];
        for (let i = 1; i < substituted.length; i++) {
            encrypted[i] = substituted[i] ^ xorKey[i % keyLen] ^ encrypted[i - 1];
        }
    }
    const blob = base85Encode(encrypted);
    return { blob, xorKey, invSbox, checksum, origLen };
}

export function compressToBase85(input) {
    const encoder = new TextEncoder();
    return base85Encode(encoder.encode(input));
}

export function compressBytesToBase85(input) {
    return base85Encode(input);
}

export function compress(input) {
    return deflateRaw(input, { level: 9 });
}

export function decompress(input) {
    return inflateRaw(input);
}
